const quizData = [
    {
        question: "What type of heat transfer occurs when you touch a hot stove?",
        options: ["Conduction", "Convection", "Radiation"],
        correct: 0
    },
    {
        question: "What type of heat transfer is responsible for the warmth of the Sun?",
        options: ["Conduction", "Convection", "Radiation"],
        correct: 2
    },
    {
        question: "Boiling water circulates heat through what process?",
        options: ["Conduction", "Convection", "Radiation"],
        correct: 1
    },
    {
        question: "What type of heat transfer occurs through direct contact?",
        options: ["Conduction", "Convection", "Radiation"],
        correct: 0
    },
    {
        question: "What process warms the air above a hot surface?",
        options: ["Conduction", "Convection", "Radiation"],
        correct: 1
    }
];

let currentQuestion = 0;
let score = 0;

function loadQuestion() {
    const questionElement = document.getElementById("question");
    const optionsContainer = document.getElementById("options");
    const progressBar = document.getElementById("progress-bar");

    questionElement.textContent = quizData[currentQuestion].question;
    optionsContainer.innerHTML = ""; // Clear previous options

    quizData[currentQuestion].options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.onclick = () => checkAnswer(index);
        optionsContainer.appendChild(button);
    });

    // Update the progress bar
    const progress = ((currentQuestion / quizData.length) * 100).toFixed(2);
    progressBar.style.width = `${progress}%`;
}

function checkAnswer(selected) {
    const isCorrect = selected === quizData[currentQuestion].correct;
    if (isCorrect) {
        alert("Correct! 🎉");
        score++;
    } else {
        alert("Wrong! 😞 The correct answer is: " + quizData[currentQuestion].options[quizData[currentQuestion].correct]);
    }

    currentQuestion++;
    document.getElementById("score").textContent = score;

    if (currentQuestion < quizData.length) {
        loadQuestion();
    } else {
        endQuiz();
    }
}

function endQuiz() {
    document.getElementById("question-container").style.display = "none";
    document.getElementById("progress-bar").style.width = "100%";
    document.getElementById("score-container").innerHTML = `
        🎯 Your final score is: <strong>${score} / 5</strong>
    `;
    document.getElementById("restart-btn").style.display = "inline-block";
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    document.getElementById("question-container").style.display = "block";
    document.getElementById("progress-bar").style.width = "0%";
    document.getElementById("score").textContent = score;
    document.getElementById("restart-btn").style.display = "none";
    loadQuestion();
}

// Initialize the quiz
loadQuestion();
